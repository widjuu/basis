/*
 * JposEntryTest.java
 *
 * Created on 10 ������� 2011 �., 11:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author V.Kravtsov
 */

import java.io.*;
import java.text.*;
import java.util.*;
import junit.framework.*;
import java.util.StringTokenizer;

import jpos.*;
import jpos.events.*;
import jpos.config.*;
import jpos.services.*;
import jpos.config.simple.*;
import jpos.config.simple.xml.*;


public class JposEntryTest extends TestCase {
    
    /**
     * Creates a new instance of StringTokenizerTest
     */
    public JposEntryTest(String testName) {
        super(testName);
    }
    
    public void testSave() 
    throws Exception
    {
        String fileName = "test.xml";
        String logicalName = "logicalName";
        System.out.println("testSave");
        JposRegPopulator populator = new XercesRegPopulator();
        JposEntryRegistry registry = new SimpleEntryRegistry(populator);
        JposEntry entry = new SimpleEntry(logicalName, populator);
        registry.addJposEntry(logicalName, entry);
        entry.addProperty("Property1", "Property1");
        entry.addProperty("Property2", "Property2");
        populator.save(registry.getEntries(), fileName);
    }
}
