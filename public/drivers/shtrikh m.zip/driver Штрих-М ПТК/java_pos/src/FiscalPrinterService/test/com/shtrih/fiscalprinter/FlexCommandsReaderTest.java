/*
 * FlexCommandsReaderTest.java
 * JUnit based test
 *
 * Created on 19 ������ 2009 �., 18:29
 */

package com.shtrih.fiscalprinter;

import junit.framework.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author V.Kravtsov
 */
public class FlexCommandsReaderTest extends TestCase {
    
    public FlexCommandsReaderTest(String testName) {
        super(testName);
    }

    /**
     * Test of loadFromXml method, of class com.shtrih.fiscalprinter.FlexCommandsReader.
     */
    public void testLoadFromXml() throws Exception {
        System.out.println("loadFromXml");
        
        FlexCommands commands = new FlexCommands();
        FlexCommandsReader instance = new FlexCommandsReader();
        instance.loadFromXml("Commands.xml", commands);
        assertEquals(132, commands.size());
    }
    
}
