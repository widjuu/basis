/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */
public class MockSmFiscalPrinter 
//implements SMFiscalPrinter 
{
    
/*
    public int taxPassword = 0;
    public int usrPassword = 1;
    public int sysPassword = 30;
    private LongPrinterStatus longStatus = new LongPrinterStatus();
    private ShortPrinterStatus shortPrinterStatus = new ShortPrinterStatus();

    public void setLongStatus(LongPrinterStatus longStatus) {
        this.longStatus = longStatus;
    }

    public void setDevice(SMPrinterDeviceInterface device) {
    }

    public void setEvents(IPrinterEvents events) {
    }

    public byte[] sendCommand(byte[] data, int timeout) throws Exception {
        return new byte[0];
    }

    public void deviceExecute(PrinterCommand command) throws Exception {
    }

    public void connect() throws Exception {
    }

    public void check(int errorCode) throws Exception {
    }

    public void execute(PrinterCommand command) throws Exception {
    }

    public void setByteTimeout(int value) {
    }

    public int getSysPassword() {
        return sysPassword;
    }

    public boolean failed(int errorCode) {
        return errorCode != 0;
    }

    public boolean succeeded(int errorCode) {
        return errorCode == 0;
    }

    public int executeCommand(PrinterCommand command) throws Exception {
        return 0;
    }

    public void setTaxPassword(int taxPassword) {
    }

    public void setUsrPassword(int usrPassword) {
    }

    public void setSysPassword(int sysPassword) {
    }

    public Beep beep() throws Exception {
        return new Beep(0);
    }

    public int activateEJ() throws Exception {
        return 0;
    }

    public LongPrinterStatus readLongStatus() throws Exception {
        return longStatus;
    }

    public ShortPrinterStatus readShortStatus() throws Exception {
        return shortPrinterStatus;
    }

    public int printString(int station, String line) throws Exception {
        return 0;
    }

    public int printBoldString(int station, String line) throws Exception {
        return 0;
    }

    public void feedPaper(int station, int lineNumber) throws Exception {
    }

    public int printStringFont(int station, int fontNumber, String line)
            throws Exception {
        return 0;
    }

    public int printLine(int station, String line, int fontNumber)
            throws Exception {
        return 0;
    }

    public String[] splitText(String text, int n, boolean wrap)
            throws Exception {
        return null;
    }

    public String[] splitText(String text, int fontNumber)
            throws Exception {
        return null;
    }

    public void printText(int station, String text, int fontNumber)
            throws Exception {
    }

    public int updateFieldInfo(int tableNumber, int fieldNumber)
            throws Exception {
         return 0;
   }

    public int writeTable(int tableNumber, int rowNumber, int fieldNumber,
            String fieldValue) throws Exception {
         return 0;
    }

    public int readTable(int tableNumber, int rowNumber, int fieldNumber,
            String[] fieldValue) throws Exception {
         return 0;
    }

    public ReadTableInfo readTableInfo(int tableNumber) throws Exception {
        return null;
    }

    public PrintCashIn printCashIn(long sum) throws Exception {
        return null;
    }

    public PrintCashOut printCashOut(long sum) throws Exception {
        return null;
    }

    public ContinuePrint continuePrint() throws Exception {
        return null;
    }

    public BeginTest startTest(int runningPeriod) throws Exception {
        return null;
    }

    public EndTest stopTest() throws Exception {
        return null;
    }

    public VoidFiscalReceipt cancelReceipt() throws Exception {
        return null;
    }

    public VoidFiscalReceipt cancelReceipt(int password) throws Exception {
        return null;
    }

    public EndFiscalReceipt closeReceipt(long sum1, long sum2, long sum3,
            long sum4, int tax1, int tax2, int tax3, int tax4, int discount,
            String text) throws Exception {
         return null;
   }

    public long getSubtotal() throws Exception {
         return 0;
   }

    public ReadOperationRegister getOperationRegister(int registerNumber)
            throws Exception {
        return null;
    }

    public ReadCashRegister getCashRegister(int registerNumber)
            throws Exception {
        return null;
    }

    public PrintEJDayReportOnDates printEJReportDates(PrinterDate date1,
            PrinterDate date2, int reportType) throws Exception {
        return null;
    }

    public PrintFMReportDates printFMReportDates(
            PrinterDate date1,
            PrinterDate date2,
            int reportType)
            throws Exception {
        return null;
    }

    public PrintEJDayReportOnDays printEJReportDays(
            int day1,
            int day2,
            int reportType)
            throws Exception {
        return null;
    }

    public PrintFMReportDays printFMReportDays(
            int day1,
            int day2,
            int reportType)
            throws Exception {
        return null;
    }

    public void printSale(long price, long quantity,
            int department, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception {
    }

    public void printVoidSale(long price, long quantity,
            int department, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception {
    }

    public PrintVoidItem printVoidItem(long price, long quantity, int department,
            int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception {
        return null;
    }

    public PrintDiscount printDiscount(
            long amount, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception {
        return null;
    }

    public PrintCharge printCharge(
            long amount, int tax1, int tax2, int tax3, int tax4,
            String text)
            throws Exception {
        return null;
    }

    public ReadFMLastRecordDate readFMLastRecordDate()
            throws Exception {
        return null;
    }

    public PrintXReport printXReport()
            throws Exception {
        return null;
    }

    public PrintZReport printZReport()
            throws Exception {
        return null;
    }

    public int writeDate(PrinterDate date)
            throws Exception {
        return 0;
    }

    public int confirmDate(PrinterDate date)
            throws Exception {
        return 0;
    }

    public void writeTime(PrinterTime time)
            throws Exception {
    }

    public void writePortParams(byte portNumber, byte baudRate, int timeout)
            throws Exception {
    }

    public void printBarcode(String barcode)
            throws Exception {
    }

    public void duplicateReceipt()
            throws Exception {
    }

    public CommandBeginFiscalReceipt beginFiscalReceipt(int receiptType)
            throws Exception {
        return null;
    }

    public int loadGraphics(int lineNumber, byte[] data)
            throws Exception {
        return 0;
    }

    public int loadGraphicsEx(int lineNumber, byte[] data)
            throws Exception {
        return 0;
    }

    public int printGraphics(int line1, int line2)
            throws Exception {
        return 0;
    }

    public void endDump()
            throws Exception {
    }

    public int printGraphicsEx(int line1, int line2)
            throws Exception {
        return 0;
    }

    public void printGraphicLine(int height, byte[] data)
            throws Exception {
    }

    public CutPaper cutPaper(int cutType)
            throws Exception {
        return null;
    }

    public void openCashDrawer(int drawerNumber)
            throws Exception {
    }

    public boolean checkEcrMode(int mode)
            throws Exception {
        return false;
    }

    public PrinterStatus waitForPrinting()
            throws Exception {
        return null;
    }

    public int[] getSupportedBaudRates()
            throws Exception {
        return null;
    }

    public boolean tryCancelReceipt(int password)
            throws Exception {
        return false;
    }

    public void writeDecimalPoint(int position)
            throws Exception {
    }

    public void resetFM()
            throws Exception {
    }

    public void sysAdminCancelReceipt()
            throws Exception {
    }

    public int getBaudRateIndex(int value)
            throws Exception {
        return 0;
    }

    public void setBaudRate(int baudRate)
            throws Exception {
    }

    public boolean connectDevice(
            int baudRate,
            int deviceBaudRate,
            int deviceByteTimeout)
            throws Exception {
         return false;
   }

    public void checkBaudRate(int value)
            throws Exception {
    }

    public void closePort()
            throws Exception {
    }

    public void writeTables(PrinterTables tables)
            throws Exception {
    }

    public void writeFields(PrinterFields fields)
            throws Exception {
    }

    public void updateTableInfo(int tableNumber)
            throws Exception {
    }

    public boolean isValidField(int tableNumber, int rowNumber, int fieldNumber)
            throws Exception {
         return false;
   }

    public void readTables(PrinterTables tables)
            throws Exception {
    }

    public PrinterStatus readShortPrinterStatus()
            throws Exception {
         return null;
   }

    public PrinterStatus readLongPrinterStatus()
            throws Exception {
        return null;
    }

    public PrinterStatus readPrinterStatus()
            throws Exception {
        return null;
    }

    public DeviceMetrics readDeviceMetrics()
            throws Exception {
        return null;
    }

    public PrinterModel getModel()
            throws Exception {
        return null;
    }

    public boolean getWrapText() {
         return false;
   }

    public void setWrapText(boolean value) {
    }

    public void checkPaper(PrinterStatus status)
            throws Exception {
    }
     * 
     */
}
