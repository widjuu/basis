/*
 * AsyncTargetTest.java
 * JUnit based test
 *
 * Created on 12 ������� 2009 �., 12:47
 */

package com.shtrih.jpos.fiscalprinter;

import junit.framework.*;
import java.io.*;
import java.util.*;
import gnu.io.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import jpos.*;
import jpos.events.*;
import jpos.config.*;
import jpos.services.*;
import jpos.config.simple.*;
import jpos.config.simple.xml.*;
import org.apache.log4j.*;
import com.shtrih.util.*;
import com.shtrih.jpos.*;
import com.shtrih.jpos.events.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.printer.ncr7167.*;
import com.shtrih.jpos.fiscalprinter.request.*;

/**
 *
 * @author V.Kravtsov
 */
public class AsyncTargetTest extends TestCase {
    
    public AsyncTargetTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    /**
     * Test of run method, of class com.shtrih.jpos.fiscalprinter.AsyncTarget.
     */
    public void testRun() {
    }
    
}
