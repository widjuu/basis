/*
 * GetFieldStructureCommandTest.java
 * JUnit based test
 *
 * Created on 13 ������� 2009 �., 11:47
 */

package com.shtrih.fiscalprinter;

import com.shtrih.util.Hex;
import junit.framework.*;
import java.io.*;
import com.shtrih.util.MethodParameter;
import java.security.InvalidParameterException;

/**
 *
 * @author V.Kravtsov
 */
public class GetFieldStructureCommandTest extends TestCase {
    
    public GetFieldStructureCommandTest(String testName) {
        super(testName);
    }

    protected void setUp() throws Exception {
    }

    protected void tearDown() throws Exception {
    }

    /**
     * Test of getCode method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testGetCode() {
        System.out.println("getCode");
        
        ReadFieldInfo instance = new ReadFieldInfo();
        int result = instance.getCode();
        assertEquals(0x2E, result);
    }

    /**
     * Test of getText method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testGetText() {
        System.out.println("getText");
        
        ReadFieldInfo instance = new ReadFieldInfo();
        String expResult = "Read field structure";
        String result = instance.getText();
        assertEquals(expResult, result);
    }

    /**
     * Test of encode method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testEncode() throws Exception {
        System.out.println("encode");
        
        CommandOutputStream out = new CommandOutputStream("");
        ReadFieldInfo instance = new ReadFieldInfo();
        
        instance.setTableNumber(0x34);
        instance.setFieldNumber(0x12);
        instance.setPassword(0x12345678);
        instance.encode(out);
        
        byte[] result = out.getData();
        byte[] expResult = {0x78, 0x56, 0x34, 0x12, 0x34, 0x12};
        assertEquals(Hex.toHex(expResult), Hex.toHex(result));
    }

    /**
     * Test of decode method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testDecode() throws Exception {
        System.out.println("decode");
        
        CommandInputStream in = new CommandInputStream("");
        CommandOutputStream out = new CommandOutputStream("");
        ReadFieldInfo instance = new ReadFieldInfo();
        
        out.writeString("fieldName  ", 40);
        out.writeByte(0x00);
        out.writeByte(0x04);
        out.writeLong(0x12345678, 4);
        out.writeLong(0x23456789, 4);
        
        in.setData(out.getData());
        instance.decode(in);
        
        assertEquals("fieldName", instance.getFieldName());
        assertEquals(0, instance.getFieldType());
        assertEquals(4, instance.getFieldSize());
        assertEquals(0x12345678, instance.getMinValue());
        assertEquals(0x23456789, instance.getMaxValue());
    }

    /**
     * Test of isFieldInteger method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testIsFieldInteger() {
        System.out.println("isFieldInteger");
        
        ReadFieldInfo instance = null;
        
        boolean expResult = true;
        boolean result = instance.isFieldInteger();
        assertEquals(expResult, result);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isFieldString method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testIsFieldString() {
        System.out.println("isFieldString");
        
        ReadFieldInfo instance = null;
        
        boolean expResult = true;
        boolean result = instance.isFieldString();
        assertEquals(expResult, result);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkFieldValue method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testCheckFieldValue() throws Exception {
        System.out.println("checkFieldValue");
        
        String fieldValue = "";
        ReadFieldInfo instance = null;
        
        instance.checkFieldValue(fieldValue);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBytes method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testGetBytes() {
        System.out.println("getBytes");
        
        String fieldValue = "";
        ReadFieldInfo instance = null;
        
        byte[] expResult = null;
        byte[] result = instance.getBytes(fieldValue);
        assertEquals(expResult, result);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of copyOfRange method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testCopyOfRange() {
        System.out.println("copyOfRange");
        
        byte[] original = null;
        int from = 0;
        int to = 0;
        
        byte[] expResult = null;
        byte[] result = ReadFieldInfo.copyOfRange(original, from, to);
        assertEquals(expResult, result);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of fieldToBytes method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testFieldToBytes() throws Exception {
        System.out.println("fieldToBytes");
        
        String fieldValue = "";
        String charsetName = "";
        ReadFieldInfo instance = null;
        
        byte[] expResult = null;
        byte[] result = instance.fieldToBytes(fieldValue, charsetName);
        assertEquals(expResult, result);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bytesToInt method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testBytesToInt() {
        System.out.println("bytesToInt");
        
        byte[] b = new byte[2];
        b[0] = (byte)0xD2;
        b[1] = (byte)0x04;
        ReadFieldInfo instance = new ReadFieldInfo();
        
        int expResult = 1234;
        int result = instance.bytesToInt(b, 2);
        assertEquals(expResult, result);
    }

    /**
     * Test of bytesToField method, of class com.shtrih.fiscalprinter.ReadFieldInfo.
     */
    public void testBytesToField() throws Exception {
        System.out.println("bytesToField");
        
        byte[] b = null;
        String charsetName = "";
        ReadFieldInfo instance = null;
        
        String expResult = "";
        String result = instance.bytesToField(b, charsetName);
        assertEquals(expResult, result);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
