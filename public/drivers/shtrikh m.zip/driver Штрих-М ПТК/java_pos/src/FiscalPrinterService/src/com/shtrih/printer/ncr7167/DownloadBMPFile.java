/*
 * DownloadBMPFile.java
 *
 * Created on 21 March 2008, 7:13
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.printer.ncr7167;

/**
 *
 * @author V.Kravtsov
 */

import com.shtrih.jpos.fiscalprinter.FiscalPrinterImpl;
import java.io.*;
import java.util.*;
import com.shtrih.jpos.*;
import org.apache.log4j.*;
import java.io.DataInputStream;

//////////////////////////////////////////////////////////////////////////
//
// This command is virtual and is not supported by NCR 7167 printer
// This command intended to load BML logo from file 
// 0x1B 0x62 fileName 0x0A
//
//////////////////////////////////////////////////////////////////////////

public final class DownloadBMPFile extends NCR7167Command 
{
    private final String fileName;
    private static Logger logger = Logger.getLogger(DownloadBMPFile.class);;
    
    
    public DownloadBMPFile(String fileName)
    {
        logger.debug("DownloadBMPFile(" + fileName + ")");
        this.fileName = fileName;
    }
        
    public String getFileName()
    {
        return fileName;
    }

    public int getId()
    {
        return NCR7167Printer.ID_DOWNLOAD_BMP_FILE;
    }
    
    public void execute(NCR7167Printer printer)
        throws Exception
    {
        logger.debug("execute");
        //service.printImage(fileName);
    }
    
    public String getText()
    {
        logger.debug("getText");
        return "Download BMP file";
    }

    public final NCR7167Command newInstance(NCR7167Command command)
    {
        logger.debug("newInstance");
        DownloadBMPFile src = (DownloadBMPFile) command;
        return new DownloadBMPFile(src.getFileName());
    }
}

