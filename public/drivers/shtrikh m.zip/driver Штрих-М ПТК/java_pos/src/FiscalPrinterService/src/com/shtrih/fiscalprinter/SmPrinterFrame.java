/*
 * SmPrinterFrame.java
 *
 * Created on 14 ������� 2010 �., 19:07
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import java.io.ByteArrayOutputStream;

public class SmPrinterFrame 
{
    private final static byte STX = 0x02;
    
    public static byte getCrc(byte[] data) {
        byte crc = (byte)data.length;
        for (int i=0;i<data.length;i++) {
            crc ^= data[i];
        }
        return crc;
    }
    
    public static byte[] encode(byte[] data) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        baos.write(STX);
        baos.write(data.length);
        baos.write(data, 0, data.length);
        baos.write(getCrc(data));
        return baos.toByteArray();
    }
}

