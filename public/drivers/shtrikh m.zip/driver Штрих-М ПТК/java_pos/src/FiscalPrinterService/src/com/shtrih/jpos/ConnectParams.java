/*
 * ConnectParams.java
 *
 * Created on July 21 2008, 11:54
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos;

/**
 *
 * @author V.Kravtsov
 */
public class ConnectParams {
    
    /** Creates a new instance of ConnectParams */
    public ConnectParams() {
    }
    
    public String portName = "";
    public int baudRate = 4800;
    public int byteTimeout = 200;
    public int deviceByteTimeout = 1000;
    public boolean searchByPortEnabled = false;
    public boolean searchByBaudRateEnabled = true;
}
