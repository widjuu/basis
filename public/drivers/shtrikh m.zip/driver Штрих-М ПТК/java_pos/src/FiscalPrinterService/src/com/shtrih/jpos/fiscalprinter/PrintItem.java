/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import com.shtrih.jpos.fiscalprinter.*;

public interface PrintItem {
    
    public void print(FiscalPrinterImpl printer) 
            throws Exception;
}
