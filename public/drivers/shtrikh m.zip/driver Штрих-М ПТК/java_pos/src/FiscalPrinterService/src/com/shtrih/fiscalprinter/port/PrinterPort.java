/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.port;

/**
 *
 * @author V.Kravtsov
 */
public interface PrinterPort {

    void open() throws Exception;

    void close() throws Exception;

    int readByte() throws Exception;

    byte[] readBytes(int len) throws Exception;

    void write(byte[] b) throws Exception;

    void write(int b) throws Exception;
    
    void setBaudRate(int baudRate) throws Exception;

    void setTimeout(int timeout) throws Exception;

    void setOpenTimeout(int openTimeout) throws Exception;
    
    int getOpenTimeout() throws Exception;
    
    void setPortName(String portName) throws Exception;
    
    Object getConnection() throws Exception;
}
