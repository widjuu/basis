/*
 * DIOExecuteCommand.java
 *
 * Created on 13 ��� 2010 �., 17:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;


public class DIOExecuteCommand {
    
    private final FiscalPrinterImpl service;
    
    /** Creates a new instance of DIOReadPaymentName */
    public DIOExecuteCommand(FiscalPrinterImpl service) 
    {
        this.service = service;
    }
    
    public void execute(int[] data, Object object)
        throws Exception
    {
        DIOUtils.checkDataMinLength(data, 1);
        DIOUtils.checkObjectNotNull(object);
        
        int timeout = data[0];
        byte[] tx = (byte[])((Object[])object)[0];
        byte[] rx = service.printer.sendCommand(tx, timeout);
        
        CommandInputStream in = new CommandInputStream(
            SMFiscalPrinterImpl.getCharsetName());
        in.setData(rx);
        PrinterCommand.checkMinLength(in.getSize(), 2);
        int commandCode = in.readByte();
        int resultCode = in.readByte();
        service.printer.check(resultCode);
        
        byte[] rxdata = new byte[rx.length-2];
        System.arraycopy(rx, 2, rxdata, 0, rx.length-2);
        ((Object[])object)[1] = rxdata;
    }
    
}
