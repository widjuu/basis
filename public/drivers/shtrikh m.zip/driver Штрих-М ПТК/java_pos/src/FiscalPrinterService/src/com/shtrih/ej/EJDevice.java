/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.ej;

/**
 *
 * @author V.Kravtsov
 */
public interface EJDevice {
    
    ///////////////////////////////////////////////////////////////////////////
    // "ReportType" constants
    
    public static final int REPORT_TYPE_SHORT   = 0;
    public static final int REPORT_TYPE_LONG    = 1;
  
    ///////////////////////////////////////////////////////////////////////////
    // Device encoding
    
    public static final String CharsetName = "Cp1251";
    
}
