/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter.receipt;

/**
 *
 * @author V.Kravtsov
 */
import jpos.*;
import org.apache.log4j.*;
import com.shtrih.jpos.fiscalprinter.*;
import com.shtrih.fiscalprinter.receipt.*;

public class CashOutReceipt extends CustomReceipt implements FiscalReceipt {

    private long total = 0; // receipt total
    private long payment = 0; // paied total
    private static Logger logger = Logger.getLogger(CashInReceipt.class);

    public CashOutReceipt(
            ReceiptPrinter printer,
            PrinterData printerData,
            FiscalDay fiscalDay,
            PrinterReceipt receipt) {
        super(printer, printerData, fiscalDay, receipt);
    }

    public void printRecCash(long amount)
            throws Exception {
        logger.debug("printRecCash");
        total += amount;
    }

    public void endFiscalReceipt(boolean printHeader)
            throws Exception {
        logger.debug("endFiscalReceipt");
        printer.getPrinter().printCashOut(total);
        printer.waitForPrinting();
    }

    public void printRecTotal(
            long total,
            long payment,
            long payType,
            String description)
            throws Exception {
        logger.debug("printRecTotal");
        printer.printPreLine();
        printer.printPostLine();
        this.payment += payment;
    }

    public boolean isPayed() {
        return payment >= total;
    }
}
