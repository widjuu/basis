/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter.receipt;

/**
 *
 * @author V.Kravtsov
 */
import com.shtrih.jpos.fiscalprinter.receipt.ReceiptPrinter;
import jpos.*;
import org.apache.log4j.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.printer.ncr7167.*;
import com.shtrih.fiscalprinter.command.*;
import com.shtrih.jpos.fiscalprinter.PrinterData;

public class ReceiptPrinterImpl implements ReceiptPrinter {

    private final SMFiscalPrinter printer;
    private final PrinterData printerData;
    private static Logger logger = Logger.getLogger(ReceiptPrinterImpl.class);

    public ReceiptPrinterImpl(SMFiscalPrinter printer,
            PrinterData printerData) {
        this.printer = printer;
        this.printerData = printerData;
    }

    public void printPreLine()
            throws Exception {
        String preLine = printerData.preLine;
        if (preLine.length() > 0) {
            printText(preLine);
            preLine = "";
        }
    }

    public void printPostLine()
            throws Exception {
        String postLine = printerData.postLine;
        if (postLine.length() > 0) {
            printText(postLine);
            postLine = "";
        }
    }

    public void openReceipt(int receiptType)
            throws Exception {
        if (printer.getModel().getCapOpenReceipt()) {
            printer.beginFiscalReceipt(receiptType);
            printer.waitForPrinting();
        }
    }

    public void printText(String text)
            throws Exception {
        printer.printText(PrinterConst.SMFP_STATION_REC, text,
                printer.getParams().fontNumber);
    }

    public long getSubtotal()
            throws Exception {
        long total = 0;
        PrinterStatus status = printer.readPrinterStatus();
        if (status.getPrinterMode().isReceiptOpened()) {
            total = printer.getSubtotal();
        }
        return total;
    }

    private String formatStrings(String line1, String line2)
            throws Exception {
        int len;
        String S = "";
        len = printer.getModel().getTextLength(printer.getParams().fontNumber) - line2.length();

        for (int i = 0; i < len; i++) {
            if (i < line1.length()) {
                S = S + line1.charAt(i);
            } else {
                S = S + " ";
            }
        }
        return S + line2;
    }

    public void printStrings(String line1, String line2)
            throws Exception {
        printText(formatStrings(line1, line2));
    }

    public SMFiscalPrinter getPrinter()
            throws Exception {
        return printer;
    }

    public void printText(int station, String text, int fontNumber)
            throws Exception {
        String data = processEscCommands(text);
        if (data.length() > 0) {
            printer.printText(station, data, fontNumber);
        }
    }

    public String printDescription(String description)
            throws Exception {
        String result = "";
        String[] lines = parseText(description);
        if (lines.length == 1) {
            result = lines[0];
        } else {
            for (int i = 0; i < lines.length; i++) {
                printText(lines[i]);
            }
        }
        return result;
    }

    public String[] parseText(String text)
            throws Exception {
        logger.debug("parseText: " + text);
        String data = processEscCommands(text);
        int fontNumber = printer.getParams().fontNumber;
        return printer.splitText(data, fontNumber);
    }

    public String processEscCommands(String text)
            throws Exception {
        return text; // !!!
    }

    public void waitForPrinting()
            throws Exception {
        printer.waitForPrinting();
    }
}