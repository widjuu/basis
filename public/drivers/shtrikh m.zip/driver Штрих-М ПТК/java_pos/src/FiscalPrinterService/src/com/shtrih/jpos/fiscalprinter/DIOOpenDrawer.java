/*
 * DIOOpenDrawer.java
 *
 * Created on 4 ���� 2010 �., 14:59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import jpos.*;
import jpos.JposException;
import com.shtrih.fiscalprinter.*;
import com.shtrih.util.Localizer;

public class DIOOpenDrawer {
    
    private FiscalPrinterImpl service;
    
    /**
     * Creates a new instance of DIOPrintBarcode
     */
    public DIOOpenDrawer(FiscalPrinterImpl service) {
        this.service = service;
    }
    
    public void execute(int[] data, Object object)
    throws Exception 
    {
        DIOUtils.checkDataNotNull(data);
        int drawerNumber = 0;
        if (data.length > 0)
        {
            drawerNumber = data[0];
        }
        service.printer.openCashDrawer(drawerNumber);
    }
    
}
