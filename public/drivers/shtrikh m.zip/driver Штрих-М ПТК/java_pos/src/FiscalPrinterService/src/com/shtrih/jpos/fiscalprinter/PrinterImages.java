/*
 * PrinterImages.java
 *
 * Created on 12 ������ 2009 �., 12:44
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

// java
import java.util.*;
// jpos
import jpos.*;
import jpos.events.*;
import jpos.config.*;
import jpos.services.*;
import jpos.config.simple.*;
import jpos.config.simple.xml.*;
// this
import com.shtrih.util.*;

public class PrinterImages implements JposConst {
    private Vector list = new Vector();
    
    /** Creates a new instance of PrinterImages */
    public PrinterImages() {
    }
    
    public void clear() {
        list.clear();
    }
    
    public int size() {
        return list.size();
    }
    
    public int getTotalSize() 
    throws Exception
    {
        int totalSize = 1;
        if (list.size() > 0) {
            PrinterImage image = get(size()-1);
            totalSize = image.getLastLine();
        }
        return totalSize;
    }
    
    public int loadImage(String fileName, FiscalPrinterImpl service)
    throws Exception {
        PrinterImage image = new PrinterImage();
        image.load(fileName, getTotalSize(), service);
        list.add(image);
        return list.size()-1;
    }
    
    public void checkIndex(int index) 
    throws Exception
    {
        if ((index < 0)||(index >= list.size())) {
            throw new JposException(JPOS_E_FAILURE,
                Localizer.getString(Localizer.InvalidImageIndex));
        }
    }
    
    public PrinterImage get(int index) 
    throws Exception
    {
        checkIndex(index);
        return (PrinterImage)list.get(index);
    }
    
    public void printImage(int index, FiscalPrinterImpl service)
    throws Exception {
        PrinterImage image = get(index);
        image.print(service);
    }
    
    public void save(JposEntry jposEntry)
    throws Exception {
        for (int i=0;i<size();i++) {
            PrinterImage image = get(i);
            image.save("Image" + String.valueOf(i), jposEntry);
        }
    }
    
    public void load(JposEntry jposEntry)
    throws Exception {
        PrinterImage image;
        for (int i=0;i<10;i++) {
            image = new PrinterImage();
            if (image.load("Image" + String.valueOf(i), jposEntry)) 
            {
                list.add(image);
            }
        }
    }
}
