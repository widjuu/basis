/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.port;

/**
 *
 * @author V.Kravtsov
 */

import java.lang.reflect.*;
import org.apache.log4j.*;


public class PrinterPortFactory {

    private static Logger logger = Logger.getLogger(PrinterPortFactory.class);
    
    public static PrinterPort createInstance(String className)
            throws Exception 
    {
        logger.debug("createInstance('" + className + "')");
        Class portClass = Class.forName(className);
        Class[] params = new Class[0];
        Constructor ctor = portClass.getConstructor(params);
        PrinterPort instance = (PrinterPort) ctor.newInstance(params);
        return instance;
    }
}
