/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.model;

/**
 *
 * @author V.Kravtsov
 */
import org.apache.log4j.*;

import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.model.*;
import com.shtrih.fiscalprinter.command.*;

public class PrinterModelImpl implements PrinterModel {
    
    protected int id;
    protected int modelID;
    protected int protocolVersion;
    protected int protocolSubVersion;
    protected String name;
    protected boolean capRecPresent;
    protected boolean capRecEmptySensor;
    protected boolean capRecNearEndSensor;
    protected boolean capRecLeverSensor;
    protected boolean capJrnPresent;
    protected boolean capJrnEmptySensor;
    protected boolean capJrnNearEndSensor;
    protected boolean capJrnLeverSensor;
    protected boolean capEJPresent;
    protected boolean capFMPresent;
    protected boolean capSlpPresent;
    protected boolean capSlpEmptySensor;
    protected boolean capSlpNearEndSensor;
    protected int numVatRates;
    protected int printWidth;
    protected boolean capPrintGraphicsLine;
    protected boolean capHasVatTable;
    protected boolean capCoverSensor;
    protected boolean capDoubleWidth;
    protected boolean capDuplicateReceipt;
    protected int amountDecimalPlace;
    protected int numHeaderLines;
    protected int numTrailerLines;
    protected int trailerTableNumber;
    protected int headerTableNumber;
    protected int headerTableRow;
    protected int trailerTableRow;
    protected int minHeaderLines;
    protected int minTrailerLines;
    protected boolean capFullCut;
    protected boolean capPartialCut;
    protected boolean capGraphics;
    protected boolean capGraphicsEx;
    protected boolean capPrintStringFont;
    protected boolean capShortStatus;
    protected boolean capFontMetrics;
    protected int maxGraphicsWidth;
    protected int maxGraphicsHeight;
    protected boolean capOpenReceipt;
    protected int[] textLength = new int[0];
    protected int[] supportedBaudRates = new int[0];
    private PrinterParameters parameters = new PrinterParameters();
    private static Logger logger = Logger.getLogger(PrinterModelImpl.class);

    /** Creates a new instance of PrinterModelDefault */
    public PrinterModelImpl() {
    }
    
    public int getId() {
        return id;
    }
    
    public int getModelID() {
        return modelID;
    }
    
    public int getProtocolVersion() {
        return protocolVersion;
    }
    
    public int getProtocolSubVersion() {
        return protocolSubVersion;
    }
    
    public String getName() {
        return name;
    }
    
    public boolean getCapRecPresent() {
        return capRecPresent;
    }
    
    public boolean getCapJrnPresent() {
        return capJrnPresent;
    }
    
    public boolean getCapRecEmptySensor() {
        return capRecEmptySensor;
    }
    
    public boolean getCapRecNearEndSensor() {
        return capRecNearEndSensor;
    }
    
    public boolean getCapRecLeverSensor() {
        return capRecLeverSensor;
    }
    
    public boolean getCapJrnEmptySensor() {
        return capJrnEmptySensor;
    }
    
    public boolean getCapJrnNearEndSensor() {
        return capJrnNearEndSensor;
    }
    
    public boolean getCapJrnLeverSensor() {
        return capJrnLeverSensor;
    }
    
    public boolean getCapEJPresent() {
        return capEJPresent;
    }
    
    public boolean getCapFMPresent() {
        return capFMPresent;
    }
    
    public boolean getCapSlpPresent() {
        return capSlpPresent;
    }
    
    public boolean getCapSlpEmptySensor() {
        return capSlpEmptySensor;
    }
    
    public boolean getCapSlpNearEndSensor() {
        return capSlpNearEndSensor;
    }
    
    public int getNumVatRates() {
        return numVatRates;
    }
    
    public int getPrintWidth() {
        return printWidth;
    }
    
    public boolean getCapPrintGraphicsLine() {
        return capPrintGraphicsLine;
    }
    
    public boolean getCapHasVatTable() {
        return capHasVatTable;
    }
    
    public boolean getCapCoverSensor() {
        return capCoverSensor;
    }
    
    public boolean getCapDoubleWidth() {
        return capDoubleWidth;
    }
    
    public boolean getCapDuplicateReceipt() {
        return capDuplicateReceipt;
    }
    
    public int getAmountDecimalPlace() {
        return amountDecimalPlace;
    }
    
    public int getTextLength(int fontNumber) {
        return textLength[fontNumber - 1];
    }
    
    public int[] getTextLength() {
        return textLength;
    }
    
    public int getNumHeaderLines() {
        return numHeaderLines;
    }
    
    public int getNumTrailerLines() {
        return numTrailerLines;
    }
    
    public int getTrailerTableNumber() {
        return trailerTableNumber;
    }
    
    public int getHeaderTableNumber() {
        return headerTableNumber;
    }
    
    public int getHeaderTableRow() {
        return headerTableRow;
    }
    
    public int getTrailerTableRow() {
        return trailerTableRow;
    }
    
    public int getMinHeaderLines() {
        return minHeaderLines;
    }
    
    public int getMinTrailerLines() {
        return minTrailerLines;
    }
    
    public int[] getSupportedBaudRates() {
        return supportedBaudRates;
    }
    
    public boolean getCapFullCut() {
        return capFullCut;
    }
    
    public boolean getCapPartialCut() {
        return capPartialCut;
    }
    
    public boolean getCapGraphics() {
        return capGraphics;
    }
    
    public boolean getCapGraphicsEx() {
        return capGraphicsEx;
    }
    
    public boolean getCapPrintStringFont() {
        return capPrintStringFont;
    }
    
    public boolean getCapShortStatus() {
        return capShortStatus;
    }
    
    public boolean getCapFontMetrics() {
        return capFontMetrics;
    }
    
    public int getMaxGraphicsWidth() {
        return maxGraphicsWidth;
    }
    
    public int getMaxGraphicsHeight() {
        return maxGraphicsHeight;
    }
    
    public boolean getCapOpenReceipt() {
        return capOpenReceipt;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setCapRecPresent(boolean capRecPresent) {
        this.capRecPresent = capRecPresent;
    }
    
    public void setCapRecEmptySensor(boolean capRecEmptySensor) {
        this.capRecEmptySensor = capRecEmptySensor;
    }
    
    public void setCapRecNearEndSensor(boolean capRecNearEndSensor) {
        this.capRecNearEndSensor = capRecNearEndSensor;
    }
    
    public void setCapRecLeverSensor(boolean capRecLeverSensor) {
        this.capRecLeverSensor = capRecLeverSensor;
    }
    
    public void setCapJrnPresent(boolean capJrnPresent) {
        this.capJrnPresent = capJrnPresent;
    }
    
    public void setCapJrnEmptySensor(boolean capJrnEmptySensor) {
        this.capJrnEmptySensor = capJrnEmptySensor;
    }
    
    public void setCapJrnNearEndSensor(boolean capJrnNearEndSensor) {
        this.capJrnNearEndSensor = capJrnNearEndSensor;
    }
    
    public void setCapJrnLeverSensor(boolean capJrnLeverSensor) {
        this.capJrnLeverSensor = capJrnLeverSensor;
    }
    
    public void setCapEJPresent(boolean capEJPresent) {
        this.capEJPresent = capEJPresent;
    }
    
    public void setCapFMPresent(boolean capFMPresent) {
        this.capFMPresent = capFMPresent;
    }
    
    public void setCapSlpPresent(boolean capSlpPresent) {
        this.capSlpPresent = capSlpPresent;
    }
    
    public void setCapSlpEmptySensor(boolean capSlpEmptySensor) {
        this.capSlpEmptySensor = capSlpEmptySensor;
    }
    
    public void setCapSlpNearEndSensor(boolean capSlpNearEndSensor) {
        this.capSlpNearEndSensor = capSlpNearEndSensor;
    }
    
    public void setNumVatRates(int numVatRates) {
        this.numVatRates = numVatRates;
    }
    
    public void setPrintWidth(int printWidth) {
        this.printWidth = printWidth;
    }
    
    public void setCapPrintGraphicsLine(boolean capPrintGraphicsLine) {
        this.capPrintGraphicsLine = capPrintGraphicsLine;
    }
    
    public void setCapHasVatTable(boolean capHasVatTable) {
        this.capHasVatTable = capHasVatTable;
    }
    
    public void setCapCoverSensor(boolean capCoverSensor) {
        this.capCoverSensor = capCoverSensor;
    }
    
    public void setCapDoubleWidth(boolean capDoubleWidth) {
        this.capDoubleWidth = capDoubleWidth;
    }
    
    public void setCapDuplicateReceipt(boolean capDuplicateReceipt) {
        this.capDuplicateReceipt = capDuplicateReceipt;
    }
    
    public void setAmountDecimalPlace(int amountDecimalPlace) {
        this.amountDecimalPlace = amountDecimalPlace;
    }
    
    public void setTextLength(int[] textLength) {
        this.textLength = textLength;
    }
    
    public void setNumHeaderLines(int numHeaderLines) {
        this.numHeaderLines = numHeaderLines;
    }
    
    public void setNumTrailerLines(int numTrailerLines) {
        this.numTrailerLines = numTrailerLines;
    }
    
    public void setTrailerTableNumber(int trailerTableNumber) {
        this.trailerTableNumber = trailerTableNumber;
    }
    
    public void setHeaderTableNumber(int headerTableNumber) {
        this.headerTableNumber = headerTableNumber;
    }
    
    public void setHeaderTableRow(int headerTableRow) {
        this.headerTableRow = headerTableRow;
    }
    
    public void setTrailerTableRow(int trailerTableRow) {
        this.trailerTableRow = trailerTableRow;
    }
    
    public void setMinHeaderLines(int minHeaderLines) {
        this.minHeaderLines = minHeaderLines;
    }
    
    public void setMinTrailerLines(int minTrailerLines) {
        this.minTrailerLines = minTrailerLines;
    }
    
    public void setSupportedBaudRates(int[] supportedBaudRates) {
        this.supportedBaudRates = supportedBaudRates;
    }
    
    public void setCapFullCut(boolean capFullCut) {
        this.capFullCut = capFullCut;
    }
    
    public void setCapPartialCut(boolean capPartialCut) {
        this.capPartialCut = capPartialCut;
    }
    
    public void setCapGraphics(boolean capGraphics) {
        this.capGraphics = capGraphics;
    }
    
    public void setCapPrintStringFont(boolean capPrintStringFont) {
        this.capPrintStringFont = capPrintStringFont;
    }
    
    public void setCapShortStatus(boolean capShortStatus) {
        this.capShortStatus = capShortStatus;
    }
    
    public void setCapFontMetrics(boolean capFontMetrics) {
        this.capFontMetrics = capFontMetrics;
    }
    
    public void setMaxGraphicsWidth(int maxGraphicsWidth) {
        this.maxGraphicsWidth = maxGraphicsWidth;
    }
    
    public void setMaxGraphicsHeight(int maxGraphicsHeight) {
        this.maxGraphicsHeight = maxGraphicsHeight;
    }
    
    public void setCapOpenReceipt(boolean capOpenReceipt) {
        this.capOpenReceipt = capOpenReceipt;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public void setModelID(int modelID) {
        this.modelID = modelID;
    }
    
    public void setProtocolVersion(int protocolVersion) {
        this.protocolVersion = protocolVersion;
    }
    
    public void setProtocolSubVersion(int protocolSubVersion) {
        this.protocolSubVersion = protocolSubVersion;
    }
    
    public void setCapGraphicsEx(boolean capGraphicsEx) {
        this.capGraphicsEx = capGraphicsEx;
    }
    
    public PrinterParameters getParameters() {
        return parameters;
    }
    
    public PrinterParameter getParameter(int id)
            throws Exception 
    {
        logger.debug("getParameter(" + String.valueOf(id) + ")");
        return parameters.itemByID(id);
    }
    
    public PrinterParameter addParameter(int id, int table, int row, int field) 
    {
        PrinterParameter parameter = new PrinterParameter();
        parameter.setId(id);
        parameter.setTableNumber(table);
        parameter.setRowNumber(row);
        parameter.setFieldNumber(field);
        parameters.add(parameter);
        return parameter;
    }
    
    public boolean getCapCutter() {
        return capFullCut || capPartialCut;
    }
}
