/*
 * PayTypes.java
 *
 * Created on 2 December 2007, 18:29
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author V.Kravtsov
 */

package com.shtrih.jpos.fiscalprinter;

import jpos.*;
import jpos.config.*;
import jpos.loader.*;
import java.util.Vector;
import java.util.Enumeration;
import org.apache.log4j.*;

import com.shtrih.jpos.*;

class PayType implements JposConst
{
    long id;                // payment type id
    int printerPayType;     // fiscal printer payment id, 0..3
    
    public PayType(int aid, int aprinterPayType)
    {
        id = aid;
        printerPayType = aprinterPayType;
    }
}

class PayTypes extends Vector implements JposConst
{
    private static Logger logger = Logger.getLogger(PayTypes.class);
    
    public PayTypes()
    {
    }
         
    public PayType addItem(int id, int printerPayType)
    {
        /*
        logger.debug("addItem(" + 
            String.valueOf(id) + ", " +
            String.valueOf(printerPayType) + ")");
         */
        
        PayType item = new PayType(id, printerPayType);
        add(item);
        return item;
    }
    
    public PayType itemById(long id)
    {
        PayType result;
        int count = size();
        for (int i=0; i < count; i++)
        {
            result = (PayType)get(i);
            if (result.id == id) return result;
        }
        return null;
    }
    
    public void loadFromJposEntry(JposEntry jposEntry)
        throws Exception
    {
        clear();
        String payTypeID = "";
        String payTypeValue = "";
        String propertyName = "";

        Enumeration props = jposEntry.getPropertyNames();
        while(props.hasMoreElements())
        {
            propertyName = (String)props.nextElement();
            if (propertyName.indexOf("payType") != -1)
            {
                payTypeValue = (String)jposEntry.getPropertyValue(propertyName);
                payTypeID = propertyName.substring(propertyName.indexOf("payType") + 7);
                addItem(Integer.parseInt(payTypeID), Integer.parseInt(payTypeValue));
            }
        }
    }
}