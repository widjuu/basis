/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.receipt;

import com.shtrih.fiscalprinter.*;

/**
 *
 * @author V.Kravtsov
 */
public class RefundReceiptItem implements ReceiptItem {

    private long price;
    private long quantity;
    private int department;
    private int tax1;
    private int tax2;
    private int tax3;
    private int tax4;
    private String text;
    private long discount = 0;

    public RefundReceiptItem(
            long price,
            long quantity,
            int department,
            int tax1,
            int tax2,
            int tax3,
            int tax4,
            String text) {
        this.price = price;
        this.quantity = quantity;
        this.department = department;
        this.tax1 = tax1;
        this.tax2 = tax2;
        this.tax3 = tax3;
        this.tax4 = tax4;
        this.text = text;
    }

    public long getPrice() {
        return price;
    }

    public long getQuantity() {
        return quantity;
    }

    public int getDepartment() {
        return department;
    }

    public int getTax1() {
        return tax1;
    }

    public int getTax2() {
        return tax2;
    }

    public int getTax3() {
        return tax3;
    }

    public int getTax4() {
        return tax4;
    }

    public String getText() {
        return text;
    }

    public void print(SMFiscalPrinter printer)
            throws Exception {
        printer.printRefund(
                getPrice(),
                getQuantity(),
                getDepartment(),
                getTax1(),
                getTax2(),
                getTax3(),
                getTax4(),
                getText());
    }

    public int getId() {
        return RECEIPT_ITEM_REFUND;
    }

    public String getDescription() {
        return text;
    }

    public long getAmount() {
        return PrinterAmount.getAmount(price, quantity);
    }

    public long getDiscount() {
        return discount;
    }

    public void setDiscount(long value) {
        discount = value;
    }
    
    public void addDiscount(long amount){
        discount += amount;
    }
    
}
