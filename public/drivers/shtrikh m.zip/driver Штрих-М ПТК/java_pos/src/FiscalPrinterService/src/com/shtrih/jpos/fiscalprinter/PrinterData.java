/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */
public class PrinterData 
{
    public boolean checkTotal;
    public int department = 1;
    public String preLine = "";
    public String postLine = "";
    public int recCloseSleepTime = 0;
    public String closeReceiptText = "";
    public String subtotalText = "SUBTOTAL";
    public static final String TEXT_REC_CANCEL = "RECEIPT CANCELLED";
}
