/*
 * ReceiptImages.java
 *
 * Created on 12 ������ 2009 �., 15:25
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import java.util.*;
import jpos.*;
import jpos.config.JposEntry;

public class ReceiptImages {
    
    private Vector list = new Vector();
    
    /** Creates a new instance of ReceiptImages */
    public ReceiptImages() {
    }
    
    public void clear()
    {
        list.clear();
    }
    
    public void add(ReceiptImage image)
    {
        list.add(image);
    }
    
    public void print(int position, FiscalPrinterImpl service)
        throws Exception 
    {
        for (int i=0;i<list.size();i++)
        {
            ReceiptImage image = (ReceiptImage)list.get(i);
            if (image.getEnabled()&&(image.getPosition() == position))
            {
                service.printImage(image.getImageIndex());
            }
        }
    }
        
    public void save(JposEntry jposEntry)
        throws Exception 
    {
        for (int i=0;i<list.size();i++)
        {
            ReceiptImage image = (ReceiptImage)list.get(i);
            image.save("ReceiptImage" + String.valueOf(i), jposEntry);
        }
    }
        
    public void load(JposEntry jposEntry)
        throws Exception 
    {
        ReceiptImage image;
        for (int i=0;i<10;i++)
        {
            image = new ReceiptImage();
            if (image.load("ReceiptImage" + String.valueOf(i), jposEntry))
            {
                list.add(image);
            }
        }
    }
}
