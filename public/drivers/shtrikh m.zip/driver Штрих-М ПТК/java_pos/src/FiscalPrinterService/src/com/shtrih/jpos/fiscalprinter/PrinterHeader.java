    /*
 * PrinterHeader.java
 *
 * Created on March 21 2008, 14:58
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter;

import jpos.*;
import java.util.*;
import org.apache.log4j.*;
import jpos.config.JposEntry;

import com.shtrih.util.*;
import com.shtrih.util.Localizer;
import com.shtrih.printer.ncr7167.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;

public class PrinterHeader implements JposConst {

    private final int numLines;
    private final Vector list = new Vector();
    private PrinterImage image = new PrinterImage();
    private static Logger logger = Logger.getLogger(PrinterHeader.class);
    private final FiscalPrinterImpl service;

    /** Creates a new instance of PrinterHeader */
    public PrinterHeader(int numLines, FiscalPrinterImpl service) {
        this.numLines = numLines;
        this.service = service;
        setDefaults();
    }

    public void setDefaults() {
        list.clear();
        for (int i = 0; i < numLines; i++) {
            list.add(new HeaderLine("", false));
        }
    }

    public int getNumLines() {
        return numLines;
    }

    // check lineNumber
    public void checkIndex(int index)
            throws Exception {
        if ((index < 0) || (index >= list.size())) {
            throw new JposException(JPOS_E_ILLEGAL,
                    Localizer.getString(Localizer.InvalidLineNumber));
        }
    }

    public void setLine(int lineNumber, String text, boolean doubleWidth)
            throws Exception {
        logger.debug("setLine");

        checkIndex(lineNumber - 1);

        String line = processEscCommands(text);
        list.set(lineNumber - 1, new HeaderLine(line, doubleWidth));
    }

    public FiscalPrinterParams getParams() {
        return service.printer.getParams();
    }

    public String processEscCommands(String text)
            throws Exception {
        String line = text;
        if (getParams().escCommandsEnabled) {
            NCR7167Printer escPrinter = new NCR7167Printer(service.printer);
            line = escPrinter.parse(
                    text.getBytes(
                    getParams().stringEncoding),
                    getParams().stringEncoding);

            DownloadBMPFile command;
            command = (DownloadBMPFile) escPrinter.find(escPrinter.ID_DOWNLOAD_BMP_FILE);
            if (command != null) {
                image.load(command.getFileName(), 1, service);
                service.graphicsLine = image.getHeight() + 1;
            }
        }
        return line;
    }

    public HeaderLine get(int index)
            throws Exception {
        checkIndex(index);
        return (HeaderLine) list.get(index);
    }

    public void save(JposEntry jposEntry, String prefix)
            throws Exception {
        image.save(prefix, jposEntry);
        for (int i = 0; i < list.size(); i++) {
            HeaderLine line = get(i);
            jposEntry.addProperty(prefix + String.valueOf(i), line.getText());
            jposEntry.addProperty(prefix + String.valueOf(i) + "doubleWidth",
                    StringUtils.boolToStr(line.getDoubleWidth()));
        }
    }

    public void load(JposEntry jposEntry, String prefix,
            FiscalPrinterImpl service)
            throws Exception {
        image.load(prefix, jposEntry);
        service.graphicsLine = image.getHeight() + 1;
        for (int i = 0; i < numLines; i++) {
            String text = "";
            boolean doubleWidth = false;
            String propertyName = "";
            // text
            propertyName = prefix + String.valueOf(i);
            if (jposEntry.hasPropertyWithName(propertyName)) {
                text = (String) jposEntry.getPropertyValue(propertyName);
            }
            // doubleWidth
            propertyName = prefix + String.valueOf(i) + "doubleWidth";
            if (jposEntry.hasPropertyWithName(propertyName)) {
                String line = (String) jposEntry.getPropertyValue(propertyName);
                doubleWidth = line.equals("1");
            }
            list.set(i, new HeaderLine(text, doubleWidth));
        }
    }

    public void printImage(FiscalPrinterImpl service)
            throws Exception {
        image.print(service);
    }
}
