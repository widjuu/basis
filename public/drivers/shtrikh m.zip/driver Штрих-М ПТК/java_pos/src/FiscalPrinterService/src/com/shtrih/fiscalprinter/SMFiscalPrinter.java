/*
 * SmFiscalPrinterInterface.java
 *
 * Created on 15 October 2010 г., 11:26
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import com.shtrih.ej.*;
import com.shtrih.jpos.*;
import com.shtrih.barcode.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.port.*;
import com.shtrih.fiscalprinter.model.*;
import com.shtrih.fiscalprinter.table.*;
import com.shtrih.fiscalprinter.command.*;
import com.shtrih.jpos.fiscalprinter.*;


public interface SMFiscalPrinter {

    public FiscalPrinterParams getParams();

    public PrinterPort getPrinterPort();

    public void setPrinterPort(PrinterPort printerPort);

    public SMPrinterDevice getDevice();

    public void setDevice(SMPrinterDevice device);

    public void setEvents(IPrinterEvents events);

    public byte[] sendCommand(byte[] data, int timeout) throws Exception;

    public void deviceExecute(PrinterCommand command) throws Exception;

    public void connect() throws Exception;

    public void check(int errorCode) throws Exception;

    public void execute(PrinterCommand command) throws Exception;

    public void setByteTimeout(int value);

    public int getSysPassword();

    public int getUsrPassword();
    
    public int getTaxPassword();
    
    public boolean failed(int errorCode);

    public boolean succeeded(int errorCode);

    public int executeCommand(PrinterCommand command) throws Exception;

    public void setTaxPassword(int taxPassword);

    public void setUsrPassword(int usrPassword);

    public void setSysPassword(int sysPassword);

    public Beep beep() throws Exception;

    public int activateEJ() throws Exception;

    public int printEJActivationReport() throws Exception;
    
    public int initEJArchive() throws Exception;
    
    public int testEJArchive() throws Exception;
    
    public int closeEJArchive() throws Exception;
    
    public int cancelEJDocument() throws Exception;
    
    public int writeEJErrorCode(int errorCode) throws Exception;
    
    public LongPrinterStatus readLongStatus() throws Exception;

    public ShortPrinterStatus readShortStatus() throws Exception;

    public int printString(int station, String line) throws Exception;

    public int printBoldString(int station, String line) throws Exception;

    public void feedPaper(int station, int lineNumber) throws Exception;

    public int printStringFont(int station, int fontNumber, String line)
            throws Exception;

    public int printLine(int station, String line, int fontNumber)
            throws Exception;

    public String[] splitText(String text, int n, boolean wrap)
            throws Exception;

    public String[] splitText(String text, int fontNumber)
            throws Exception;

    public void printText(int station, String text, int fontNumber)
            throws Exception;

    public int updateFieldInfo(int tableNumber, int fieldNumber)
            throws Exception;

    public int writeTable(int tableNumber, int rowNumber, int fieldNumber,
            String fieldValue) throws Exception;

    public int readTable(int tableNumber, int rowNumber, int fieldNumber,
            String[] fieldValue) throws Exception;

    public int readTableInfo(int tableNumber, Object[] out) throws Exception;

    public ReadTableInfo readTableInfo(int tableNumber) throws Exception;

    public PrintCashIn printCashIn(long sum) throws Exception;

    public PrintCashOut printCashOut(long sum) throws Exception;

    public ContinuePrint continuePrint() throws Exception;

    public BeginTest startTest(int runningPeriod) throws Exception;

    public EndTest stopTest() throws Exception;

    public VoidFiscalReceipt cancelReceipt() throws Exception;

    public VoidFiscalReceipt cancelReceipt(int password) throws Exception;

    public EndFiscalReceipt closeReceipt(long sum1, long sum2, long sum3,
            long sum4, int tax1, int tax2, int tax3, int tax4, int discount,
            String text) throws Exception;

    public long getSubtotal() throws Exception;

    public int readOperationRegister(OperationRegister register)
            throws Exception;

    public int readOperationRegister(int number)
            throws Exception;
    
    public int readCashRegister(CashRegister register)
            throws Exception;

    public long readCashRegister(int number)
            throws Exception;
    
    public PrintEJDayReportOnDates printEJDayReportOnDates(
            EJDate date1, EJDate date2, int reportType) throws Exception;

    public PrintFMReportDates printFMReportDates(
            PrinterDate date1,
            PrinterDate date2,
            int reportType)
            throws Exception;

    public PrintEJDayReportOnDays printEJReportDays(
            int day1,
            int day2,
            int reportType)
            throws Exception;

    public PrintFMReportDays printFMReportDays(
            int day1,
            int day2,
            int reportType)
            throws Exception;

    public void printSale(long price, long quantity,
            int department, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public void printVoidSale(long price, long quantity,
            int department, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public void printRefund(long price, long quantity,
            int department, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public void printVoidRefund(long price, long quantity,
            int department, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public PrintVoidItem printVoidItem(long price, long quantity, int department,
            int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public PrintDiscount printDiscount(
            long amount, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public PrintVoidDiscount printVoidDiscount(
            long amount, int tax1, int tax2, int tax3, int tax4, String text)
            throws Exception;

    public PrintCharge printCharge(
            long amount, int tax1, int tax2, int tax3, int tax4,
            String text)
            throws Exception;

    public PrintVoidCharge printVoidCharge(
            long amount, int tax1, int tax2, int tax3, int tax4,
            String text)
            throws Exception;

    public ReadFMLastRecordDate readFMLastRecordDate()
            throws Exception;

    public PrintXReport printXReport()
            throws Exception;

    public PrintZReport printZReport()
            throws Exception;

    public int printDepartmentReport()
            throws Exception;

    public int printTaxReport()
            throws Exception;

    public int printTotalizers()
            throws Exception;

    public int writeDate(PrinterDate date)
            throws Exception;

    public int confirmDate(PrinterDate date)
            throws Exception;

    public void writeTime(PrinterTime time)
            throws Exception;

    public void writePortParams(int portNumber, int baudRate, int timeout)
            throws Exception;

    public void printBarcode(String barcode)
            throws Exception;

    public void duplicateReceipt()
            throws Exception;

    public BeginFiscalReceipt beginFiscalReceipt(int receiptType)
            throws Exception;

    public int loadGraphics(int lineNumber, byte[] data)
            throws Exception;

    public int loadGraphicsEx(int lineNumber, byte[] data)
            throws Exception;

    public int printGraphics(int line1, int line2)
            throws Exception;

    public void endDump()
            throws Exception;

    public int printGraphicsEx(int line1, int line2)
            throws Exception;

    public void printGraphicLine(int height, byte[] data)
            throws Exception;

    public int cutPaper(int cutType)
            throws Exception;

    public void openCashDrawer(int drawerNumber)
            throws Exception;

    public boolean checkEcrMode(int mode)
            throws Exception;

    public PrinterStatus waitForPrinting()
            throws Exception;

    public int[] getSupportedBaudRates()
            throws Exception;

    public boolean tryCancelReceipt(int password)
            throws Exception;

    public void writeDecimalPoint(int position)
            throws Exception;

    public void resetFM()
            throws Exception;

    public void sysAdminCancelReceipt()
            throws Exception;

    public int getBaudRateIndex(int value)
            throws Exception;

    public void setBaudRate(int baudRate)
            throws Exception;

    public boolean connectDevice(
            int baudRate,
            int deviceBaudRate,
            int deviceByteTimeout)
            throws Exception;

    public void checkBaudRate(int value)
            throws Exception;

    public void closePort()
            throws Exception;

    public void writeTables(PrinterTables tables)
            throws Exception;

    public void writeFields(PrinterFields fields)
            throws Exception;

    public void updateTableInfo(int tableNumber)
            throws Exception;

    public boolean isValidField(int tableNumber, int rowNumber, int fieldNumber)
            throws Exception;

    public void readTables(PrinterTables tables)
            throws Exception;

    public PrinterStatus readShortPrinterStatus()
            throws Exception;

    public PrinterStatus readLongPrinterStatus()
            throws Exception;

    public PrinterStatus readPrinterStatus()
            throws Exception;

    public DeviceMetrics readDeviceMetrics()
            throws Exception;

    public PrinterModel getModel()
            throws Exception;

    public boolean getWrapText();

    public void setWrapText(boolean value);

    public void checkPaper(PrinterStatus status)
            throws Exception;

    public int bufferZReport()
            throws Exception;

    public int printBufferedZReport()
            throws Exception;

    public int printTrailer()
            throws Exception;

    public int printHeader()
            throws Exception;

    public byte[] getTxData();

    public byte[] getRxData();

    public int initTables()
            throws Exception;
    
    public void readTable(PrinterTable table)
            throws Exception;
    
    public void writeField(PrinterField field)
            throws Exception;

    public void readField(PrinterField field)
            throws Exception;
    
    public void loadImageData(int lineNumber, byte[] data)
            throws Exception;
    
    public void printImage(int line1, int line2)
            throws Exception ;
    
    public int stopEJPrint()
            throws Exception;
    
    public int printEJDocument(int macNumber)    
            throws Exception;
    
    public int printEJDayReport(int dayNumber)    
            throws Exception;
   
    public int printEJDayTotal(int dayNumber)    
            throws Exception;
    
    public int readEJDayReport(int dayNumber)    
            throws Exception;
    
    public int readEJDayTotals(int dayNumber)    
            throws Exception;
    
    public void writeParameter(int parameterID, int value)    
            throws Exception;
    
    public void writeParameter(int parameterID, boolean value)    
            throws Exception;
    
    public void writeParameter(int parameterID, String value)    
            throws Exception;
    
    public String readParameter(int parameterID)    
            throws Exception;
    
    public void printBarcode(PrinterBarcode barcode)
            throws Exception;
    
    public void sleep(long millis);
    
    public PrinterImages getPrinterImages();
    
    public String processEscCommands(String text)
            throws Exception;
    
}