/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */
import java.io.*;
import java.util.*;
import java.text.*;
import org.apache.log4j.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;

public class CsvRegisterReportWriter {

    private static final String Separator = ";";
    private static Logger logger = Logger.getLogger(CsvRegisterReportWriter.class);

    public static void execute(RegisterReport report, String fileName)
            throws Exception {
        if (fileName == "") {
            fileName = "ZReport.csv";
        }

        BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(
                new FileOutputStream(fileName), "UTF8"));

        Vector cashRegisters = report.getCashRegisters();
        for (int i = 0; i < cashRegisters.size(); i++) {
            CashRegister cashRegister = (CashRegister) cashRegisters.get(i);

            String line = "0" + Separator
                    + String.valueOf(cashRegister.getNumber()) + Separator
                    + String.valueOf(cashRegister.getValue()) + Separator
                    + String.valueOf(cashRegister.getEngName(cashRegister.getNumber()));
            logger.debug(line);
            writer.write(line);
            writer.newLine();
        }

        Vector operRegisters = report.getOperRegisters();

        for (int i = 0;
                i < operRegisters.size();
                i++) {
            OperationRegister operRegister = (OperationRegister) operRegisters.get(i);

            String line = "1" + Separator
                    + String.valueOf(operRegister.getNumber()) + Separator
                    + String.valueOf(operRegister.getValue()) + Separator
                    + String.valueOf(operRegister.getEngName(operRegister.getNumber()));
            logger.debug(line);
            writer.write(line);
            writer.newLine();
        }
        writer.flush();
    }
}
