/*
 * TextLine.java
 *
 * Created on 10 ���� 2010 �., 16:54
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.command;

import com.shtrih.jpos.fiscalprinter.PrintItem;
import com.shtrih.jpos.fiscalprinter.*;

/**
 *
 * @author V.Kravtsov
 */
public class TextLine implements PrintItem {

    private final int station;
    private final int font;
    private final String line;

    /** Creates a new instance of TextLine */
    public TextLine(int station, int font, String line) {
        this.station = station;
        this.font = font;
        this.line = line;
    }

    public void print(FiscalPrinterImpl printer) 
            throws Exception {
        printer.doPrintRecMessage(station, font, line);
    }
}
