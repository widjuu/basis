/*
 * PrintCharge.java
 *
 * Created on April 2 2008, 20:53
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.command;

/**
 *
 * @author V.Kravtsov
 */
import com.shtrih.util.MethodParameter;

/****************************************************************************

Surcharge

Command:	87H. Length: 54 bytes.
�	Operator password (4 bytes)
�	Surcharge value (5 bytes) 0000000000�9999999999
�	Tax 1 (1 byte) �0� � no tax, �1���4� � tax ID
�	Tax 2 (1 byte) �0� � no tax, �1���4� � tax ID
�	Tax 3 (1 byte) �0� � no tax, �1���4� � tax ID
�	Tax 4 (1 byte) �0� � no tax, �1���4� � tax ID
�	Text (40 bytes)

Answer:		87H. Length: 3 bytes.
�	Result Code (1 byte)
�	Operator index number (1 byte) 1�30

 ****************************************************************************/
public final class PrintCharge extends PrinterCommand {
    // in

    private int password;
    private long amount;
    private int tax1;
    private int tax2;
    private int tax3;
    private int tax4;
    private String text;
    // out
    private int operator;

    /**
     * Creates a new instance of PrintCharge
     */
    public PrintCharge() {
        super();
    }

    public final int getCode() {
        return 0x87;
    }

    public final String getText() {
        return "Surcharge";
    }

    public final void encode(CommandOutputStream out)
            throws Exception {
        out.writeInt(getPassword());
        out.writeLong(getAmount(), 5);
        out.writeByte(getTax1());
        out.writeByte(getTax2());
        out.writeByte(getTax3());
        out.writeByte(getTax4());
        out.writeString(getText(), PrinterConst.MIN_TEXT_LENGTH);
    }

    public final void decode(CommandInputStream in)
            throws Exception {
        setOperator(in.readByte());
    }

    public int getPassword() {
        return password;
    }

    public long getAmount() {
        return amount;
    }

    public int getTax1() {
        return tax1;
    }

    public int getTax2() {
        return tax2;
    }

    public int getTax3() {
        return tax3;
    }

    public int getTax4() {
        return tax4;
    }

    public int getOperator() {
        return operator;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public void setTax1(int tax1) {
        this.tax1 = tax1;
    }

    public void setTax2(int tax2) {
        this.tax2 = tax2;
    }

    public void setTax3(int tax3) {
        this.tax3 = tax3;
    }

    public void setTax4(int tax4) {
        this.tax4 = tax4;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setOperator(int operator) {
        this.operator = operator;
    }
}
