/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.command;

/**
 *
 * @author V.Kravtsov
 */
public class PrinterParameter {

    private int id;
    private int tableNumber;
    private int rowNumber;
    private int fieldNumber;
    private final ParameterValues values = new ParameterValues();

    public PrinterParameter() {
    }

    public ParameterValues getValues() {
        return values;
    }

    public int getFieldValue(int value)
            throws Exception {
        Integer result = values.getFieldValue(value);
        if (result == null) {
            return value;
        }
        return result.intValue();
    }

    public int getId() {
        return id;
    }

    public int getTableNumber() {
        return tableNumber;
    }

    public int getRowNumber() {
        return rowNumber;
    }

    public int getFieldNumber() {
        return fieldNumber;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTableNumber(int tableNumber) {
        this.tableNumber = tableNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public void setFieldNumber(int fieldNumber) {
        this.fieldNumber = fieldNumber;
    }

}
