/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.ej;

/**
 *
 * @author V.Kravtsov
 */
public class EJStatus {

    private final long docMAC;
    private final EJDate docDate;
    private final EJTime docTime;
    private final long docMACNumber;
    private final long serialNumber;
    private final EJFlags flags;

    public EJStatus(
        EJDate docDate,
        EJTime docTime,
        long docMAC,
        long docMACNumber,
        long serialNumber,
        EJFlags flags
            )
    {
        this.docDate = docDate;
        this.docTime = docTime;
        this.docMAC = docMAC;
        this.docMACNumber = docMACNumber;
        this.serialNumber = serialNumber;
        this.flags = flags;
    }

    public long getDocMAC() {
        return docMAC;
    }

    public EJDate getDocDate() {
        return docDate;
    }

    public EJTime getDocTime() {
        return docTime;
    }

    public long getDocMACNumber() {
        return docMACNumber;
    }

    public long getSerialNumber() {
        return serialNumber;
    }

    public EJFlags getFlags() {
        return flags;
    }

}
