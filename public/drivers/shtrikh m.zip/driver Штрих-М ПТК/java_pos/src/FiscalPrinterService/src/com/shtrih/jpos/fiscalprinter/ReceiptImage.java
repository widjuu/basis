/*
 * ReceiptImage.java
 *
 * Created on 12 ������ 2009 �., 15:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */
import jpos.config.JposEntry;

public class ReceiptImage{
    
    private boolean enabled = false;
    private int imageIndex = 0;
    private int position = 0;
        
    /**
     * Creates a new instance of ReceiptImage
     */
    public ReceiptImage() 
    {
    }
    
    public ReceiptImage(boolean enabled, int imageIndex, int position) 
    {
        this.enabled = enabled;
        this.imageIndex = imageIndex;
        this.position = position;
    }
    
    public boolean getEnabled()
    {
        return enabled;
    }
    
    public int getImageIndex()
    {
        return imageIndex;
    }
    
    public int getPosition()
    {
        return position;
    }
    
    public void save(String prefix, JposEntry jposEntry)
        throws Exception 
    {
        jposEntry.addProperty(prefix + "ImageIndex", new Integer(imageIndex));
        jposEntry.addProperty(prefix + "Position", new Integer(position));
        jposEntry.addProperty(prefix + "Enabled", new Boolean(enabled));
    }
    
    public boolean load(String prefix, JposEntry jposEntry)
        throws Exception  
    {
        String propName;
        
        // ImageIndex
        propName = prefix + "ImageIndex";
        if (!jposEntry.hasPropertyWithName(propName))
            return false;
        imageIndex = ((Integer)jposEntry.getPropertyValue(propName)).intValue();
        
        // Position
        propName = prefix + "Position";
        if (!jposEntry.hasPropertyWithName(propName))
            return false;
        position = ((Integer)jposEntry.getPropertyValue(propName)).intValue();
            
        // Enabled
        propName = prefix + "Enabled";
        if (!jposEntry.hasPropertyWithName(propName))
            return false;
        enabled = ((Boolean)jposEntry.getPropertyValue(propName)).booleanValue();
        return true;
    }
    
}
