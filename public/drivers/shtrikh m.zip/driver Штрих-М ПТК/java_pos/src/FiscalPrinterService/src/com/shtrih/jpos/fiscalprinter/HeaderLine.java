/*
 * HeaderLine.java
 *
 * Created on 23 ������ 2009 �., 20:39
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */
public class HeaderLine {
    
    private final String text;
    private final boolean doubleWidth;
    
    /** Creates a new instance of HeaderLine */
    public HeaderLine(String text, boolean doubleWidth) {
        this.text = text;
        this.doubleWidth = doubleWidth;
    }
    
    public String getText(){
        return text;
    }
    
    public boolean getDoubleWidth()
    {
        return false;
    }
}
