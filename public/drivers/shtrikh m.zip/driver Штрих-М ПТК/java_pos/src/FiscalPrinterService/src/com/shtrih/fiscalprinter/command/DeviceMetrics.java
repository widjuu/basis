/*
 * DeviceMetrics.java
 *
 * Created on 8 ���� 2010 �., 18:15
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.fiscalprinter.command;

/**
 *
 * @author V.Kravtsov
 */
public class DeviceMetrics {
    
    private final int deviceType;
    private final int deviceSubType;
    private final int protocolVersion;
    private final int protocolSubVersion;
    private final int model;
    private final int language;
    private final String deviceName;
    
    /** Creates a new instance of DeviceMetrics */
    public DeviceMetrics(
        int deviceType,
        int deviceSubType,
        int protocolVersion,
        int protocolSubVersion,
        int model,
        int language,
        String deviceName) 
    {
        this.deviceType = deviceType;
        this.deviceSubType = deviceSubType;
        this.protocolVersion = protocolVersion;
        this.protocolSubVersion = protocolSubVersion;
        this.model = model;
        this.language = language;
        this.deviceName = deviceName;
    }
    
    public int getDeviceType(){
        return deviceType;
    }
    
    public int getDeviceSubType() {
        return deviceType;
    }
    
    public int getProtocolVersion() {
        return protocolVersion;
    }
    
    public int getProtocolSubVersion() {
        return protocolSubVersion;
    }
    
    public int getModel() {
        return model;
    }
    
    public int getLanguage() {
        return language;
    }
    
    public String getDeviceName() {
        return deviceName;
    }
    
    public boolean getCapPrintGraphicsLine()
    {
        return (protocolVersion >= 1)&&(protocolSubVersion >= 9);
    }
    
    public boolean getCapGraphicsEx()
    {
        return (protocolVersion >= 1)&&(protocolSubVersion >= 3);
    }
    
    
}
