/*
 * FiscalPrinterParams.java
 *
 * Created on 13 ��� 2010 �., 14:37
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.fiscalprinter.command;

/**
 *
 * @author V.Kravtsov
 */

public class FiscalPrinterParams {
    
    public int fontNumber = 1;
    public String stringEncoding = "";
    public int statusCommand = PrinterConst.SMFP_STATUS_COMMAND_11H;
    public boolean escCommandsEnabled = false;
    public static final int defaultBarcodePrintTime = 200;
    public int barcodePrintTime = defaultBarcodePrintTime;
    
    /** Creates a new instance of FiscalPrinterParams */
    public FiscalPrinterParams() {
    }
    
}
