/*
 * DIOExecuteCommandStr.java
 *
 * Created on 14 ��� 2010 �., 11:23
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import jpos.JposConst;
import jpos.JposException;
import org.apache.log4j.*;

import com.shtrih.util.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;

public class DIOExecuteCommandStr {
    
    private final FiscalPrinterImpl service;
    static Logger logger = Logger.getLogger(DIOExecuteCommandStr.class);
    
    /** Creates a new instance of DIOReadPaymentName */
    public DIOExecuteCommandStr(FiscalPrinterImpl service) 
    {
        this.service = service;
    }
    
    public void execute(int[] data, Object object)
        throws Exception
    {
        logger.debug("execute");
        DIOUtils.checkDataMinLength(data, 2);
        DIOUtils.checkObjectNotNull(object);
        
        int commandCode = data[0];
        int timeout = data[1];
        String inParams = (String)((Object[])object)[0];
        FlexCommand command = service.getCommands().itemByCode(commandCode);
        if (command == null) 
            throw new Exception(Localizer.getString(Localizer.CommandNotFound));
        
        command.setTimeout(timeout);
        CommandParamsTextReader.read(inParams, command.getInParams());
        service.printer.execute(command);
        service.printer.check(command.getResultCode());
        String outParams = CommandParamsTextWriter.write(command.getOutParams());
        ((Object[])object)[1] = outParams;
    }
}
