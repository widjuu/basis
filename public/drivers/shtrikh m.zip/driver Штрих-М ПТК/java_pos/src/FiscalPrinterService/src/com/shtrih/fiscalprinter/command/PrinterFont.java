/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.command;

/**
 *
 * @author V.Kravtsov
 */

import com.shtrih.util.MethodParameter;

public class PrinterFont {

    private final int value;

    public PrinterFont(int value) 
    {
        MethodParameter.checkRange(value, 0, 7, "font number");
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
