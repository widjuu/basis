/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.receipt;

import com.shtrih.fiscalprinter.*;

/**
 *
 * @author V.Kravtsov
 */
public class SaleReceiptItem implements ReceiptItem {

    private final long price;
    private final long quantity;
    private final int department;
    private final int tax1;
    private final int tax2;
    private final int tax3;
    private final int tax4;
    private final String text;
    private long discount = 0;

    public SaleReceiptItem(
            long price,
            long quantity,
            int department,
            int tax1,
            int tax2,
            int tax3,
            int tax4,
            String text) {
        this.price = price;
        this.quantity = quantity;
        this.department = department;
        this.tax1 = tax1;
        this.tax2 = tax2;
        this.tax3 = tax3;
        this.tax4 = tax4;
        this.text = text;
    }

    public long getPrice() {
        return price;
    }

    public long getQuantity() {
        return quantity;
    }

    public int getDepartment() {
        return department;
    }

    public int getTax1() {
        return tax1;
    }

    public int getTax2() {
        return tax2;
    }

    public int getTax3() {
        return tax3;
    }

    public int getTax4() {
        return tax4;
    }

    public String getText() {
        return text;
    }
    
    public int getId(){
        return RECEIPT_ITEM_SALE;
    }
    
    public String getDescription(){
        return text;
    }
    
    public long getDiscount(){
        return discount;
    }
    
    public void setDiscount(long value){
        discount = value;
    }
    
    public long getAmount()
    {
        return PrinterAmount.getAmount(price, quantity);
    }
    
    public void addDiscount(long amount){
        discount += amount;
    }
    
    public void print(SMFiscalPrinter printer)
            throws Exception {
        printer.printSale(getPrice(), getQuantity(), getDepartment(), getTax1(), getTax2(), getTax3(), getTax4(), getText());
    }

}
