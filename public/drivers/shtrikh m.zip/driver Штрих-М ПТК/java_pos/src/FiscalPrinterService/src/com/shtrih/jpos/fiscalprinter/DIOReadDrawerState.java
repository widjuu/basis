/*
 * DIOReadDrawerState.java
 *
 * Created on 4 ���� 2010 �., 15:09
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import jpos.*;
import jpos.JposException;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;

public class DIOReadDrawerState {
    
    private FiscalPrinterImpl service;
    
    /**
     * Creates a new instance of DIOPrintBarcode
     */
    public DIOReadDrawerState(FiscalPrinterImpl service) {
        this.service = service;
    }
    
    public void execute(int[] data, Object object)
    throws Exception 
    {
        DIOUtils.checkDataMinLength(data, 1);
        data[0] = 0;
        PrinterFlags flags = service.readPrinterStatus().getPrinterFlags();
        if (flags.isDrawerOpened()){
            data[0] = 1;
        }
    }
}
