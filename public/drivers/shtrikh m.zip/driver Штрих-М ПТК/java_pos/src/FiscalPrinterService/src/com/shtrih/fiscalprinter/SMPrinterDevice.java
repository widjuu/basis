/*
 * SmPrinterDeviceInterface.java
 *
 * Created on 14 October 2010 �., 19:49
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.port.*;
import com.shtrih.fiscalprinter.command.*;

public interface SMPrinterDevice 
{
    public void connect() throws Exception;
    public void execute(PrinterCommand command) throws Exception;
    public byte[] sendCommand(byte[] data, int timeout) throws Exception;
    public void setByteTimeout(int value);
    public byte[] getTxData();
    public byte[] getRxData();
    public PrinterPort getPrinterPort();
    public void setPrinterPort(PrinterPort printerPort);
}
