/*
 * DIOPrintText.java
 *
 * Created on 4 ���� 2010 �., 13:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */

import jpos.*;
import jpos.JposException;
import com.shtrih.util.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;

public class DIOPrintText {
    
    private final FiscalPrinterImpl service;
    
    /** Creates a new instance of DIOReadSerial */
    public DIOPrintText(FiscalPrinterImpl service) {
        this.service = service;
    }
    
    public void execute(int[] data, Object object)
    throws Exception 
    {
        DIOUtils.checkObjectNotNull(object);
        String text = (String)object;
        
        int font = 1;
        if (data != null) {
            if (data.length > 0) {
                font = data[0];
            }
        }
        service.printRecMessageAsync(PrinterConst.SMFP_STATION_RECJRN,
            font, text);
    }
}
