/*
 * PrinterStatus.java
 *
 * Created on 11 ������ 2009 �., 17:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.fiscalprinter.command;

/**
 *
 * @author V.Kravtsov
 */
public class PrinterStatus {
    
    private final int mode;
    private final int flags;
    private final int submode;
    private final int operatorNumber;
    
    /** Creates a new instance of PrinterStatus */
    public PrinterStatus(
        int mode,
        int submode,
        int flags,
        int operatorNumber)
    {
        this.mode = mode;
        this.submode = submode;
        this.flags = flags;
        this.operatorNumber = operatorNumber;
    }
    
    public int getMode()
    {
        return mode;
    }
    
    public int getFlags()
    {
        return flags;
    }
        
    public int getSubmode()
    {
        return submode;
    }
    
    public int getOperatorNumber()
    {
        return operatorNumber;
    }
    
    public PrinterFlags getPrinterFlags()
    {
        return new PrinterFlags(flags);
    }
    
    public PrinterMode getPrinterMode()
    {
        return new PrinterMode(mode);
    }
}
