/*
 * SmFptrConst.java
 *
 * Created on 13 ������ 2009 �., 17:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.shtrih.jpos.fiscalprinter;

/**
 *
 * @author V.Kravtsov
 */
public interface SmFptrConst 
{
    
    /////////////////////////////////////////////////////////////////////
    // Report device for printReport, printPeriodicTotalsReport
    /////////////////////////////////////////////////////////////////////

    /** Report from electronic journal (EJ) **/
    public static final int SMFPTR_REPORT_DEVICE_EJ = 0;
    
    /** Report from fiscal memory (FM) **/
    public static final int SMFPTR_REPORT_DEVICE_FM = 1;
    
    /////////////////////////////////////////////////////////////////////
    // PrinterBarcode types
    /////////////////////////////////////////////////////////////////////
    
    public static final int SMFPTR_BARCODE_UPCA = 0;
    public static final int SMFPTR_BARCODE_UPCE = 1;
    public static final int SMFPTR_BARCODE_EAN13 = 2;
    public static final int SMFPTR_BARCODE_EAN8 = 3;
    public static final int SMFPTR_BARCODE_CODE39 = 4;
    public static final int SMFPTR_BARCODE_ITF = 5;
    public static final int SMFPTR_BARCODE_CODABAR = 6;
    public static final int SMFPTR_BARCODE_CODE93 = 7;
    public static final int SMFPTR_BARCODE_CODE128 = 8;
    public static final int SMFPTR_BARCODE_PDF417 = 9;
    
    /////////////////////////////////////////////////////////////////////
    // Barcode text position constants
    /////////////////////////////////////////////////////////////////////
    
    /** Not printed **/
    public static final int SMFPTR_TEXTPOS_NOTPRINTED = 0; 
    
    /** Above the bar code **/
    public static final int SMFPTR_TEXTPOS_ABOVE = 1; 
    
    /** Below the bar code **/
    public static final int SMFPTR_TEXTPOS_BELOW = 2; 
    
    /** Both above and below the bar code **/
    public static final int SMFPTR_TEXTPOS_BOTH = 3; 
    
   
    /////////////////////////////////////////////////////////////////////
    // Barcode printing constants
    /////////////////////////////////////////////////////////////////////
    
    /** PrinterBarcode is rendered and printed by device **/
    public static final int SMFPTR_PRINTTYPE_DEVICE = 0; 
    
    /** PrinterBarcode is rendered and printed by driver **/
    public static final int SMFPTR_PRINTTYPE_DRIVER = 1; 
    
    /////////////////////////////////////////////////////////////////////
    // Logo printing constants
    /////////////////////////////////////////////////////////////////////
    
    /** Logo printed after receipt header **/
    public static final int SMFPTR_LOGO_AFTER_HEADER = 0;
    
    /** Logo printed before receipt trailer **/
    public static final int SMFPTR_LOGO_BEFORE_TRAILER = 1;
    
    /** Logo printed after receipt trailer **/
    public static final int SMFPTR_LOGO_AFTER_TRAILER = 2;
    
    /** Logo printed after receipt additional trailer **/
    public static final int SMFPTR_LOGO_AFTER_ADDTRAILER = 3;

    /////////////////////////////////////////////////////////////////////
    // Report type constants
    /////////////////////////////////////////////////////////////////////
    
    /** Short report **/
    public static final int SMFPTR_REPORT_TYPE_SHORT = 0;    
    
    /** Full report **/
    public static final int SMFPTR_REPORT_TYPE_FULL = 1;    
    
    /////////////////////////////////////////////////////////////////////
    // DirectIO command constants
    /////////////////////////////////////////////////////////////////////

    /** Execute command object **/
    public static final int SMFPTR_DIO_COMMAND = 0x00;
    
    /** Print barcode object **/
    public static final int SMFPTR_DIO_PRINT_BARCODE_OBJECT = 0x01;
    
    /** Set department **/
    public static final int SMFPTR_DIO_SET_DEPARTMENT = 0x02;
    
    /** Get department **/
    public static final int SMFPTR_DIO_GET_DEPARTMENT = 0x03;
    
    /** Execute string command **/
    public static final int SMFPTR_DIO_STRCOMMAND = 0x04;
    
    /** Read table command **/
    public static final int SMFPTR_DIO_READTABLE = 0x05;
    
    /** Write table command **/
    public static final int SMFPTR_DIO_WRITETABLE = 0x06;
    
    /** Read payment type name **/
    public static final int SMFPTR_DIO_READ_PAYMENT_NAME = 0x07;
    
    /** write payment type name **/
    public static final int SMFPTR_DIO_WRITE_PAYMENT_NAME = 0x08;
    
    /** Read end of day flag **/
    public static final int SMFPTR_DIO_READ_DAY_END = 0x09;
    
    /** Print barcode command **/
    public static final int SMFPTR_DIO_PRINT_BARCODE = 0x0A;
    
    /** Load image from file **/
    public static final int SMFPTR_DIO_LOAD_IMAGE = 0x0B;
    
    /** Print image **/
    public static final int SMFPTR_DIO_PRINT_IMAGE = 0x0C;
    
    /** Clear all images **/
    public static final int SMFPTR_DIO_CLEAR_IMAGES = 0x0D;
    
    /** Set logo **/
    public static final int SMFPTR_DIO_ADD_LOGO = 0x0E;
    
    /** Clear logo **/
    public static final int SMFPTR_DIO_CLEAR_LOGO = 0x0F;
    
    /** Print black line **/
    public static final int SMFPTR_DIO_PRINT_LINE = 0x10;
    
    /** Get driver parameter **/
    public static final int SMFPTR_DIO_GET_DRIVER_PARAMETER = 0x11;
    
    /** Set driver parameter **/
    public static final int SMFPTR_DIO_SET_DRIVER_PARAMETER = 0x12;
    
    /** Print text **/
    public static final int SMFPTR_DIO_PRINT_TEXT = 0x13;
    
    /** Write table values from file **/
    public static final int SMFPTR_DIO_WRITE_TABLES = 0x14;
    
    /** Read table values to file **/
    public static final int SMFPTR_DIO_READ_TABLES = 0x15;
    
    /** Read device serial number **/
    public static final int SMFPTR_DIO_READ_SERIAL = 0x16;
    
    /** Read EJ serial number **/
    public static final int SMFPTR_DIO_READ_EJ_SERIAL = 0x17;
    
    /** Open cash drawer **/
    public static final int SMFPTR_DIO_OPEN_DRAWER = 0x18;
    
    /** Read cash drawer state **/
    public static final int SMFPTR_DIO_READ_DRAWER_STATE = 0x19;
    
    /** Read printer status **/
    public static final int SMFPTR_DIO_READ_PRINTER_STATUS = 0x1A;
    
    /** Read cash register **/
    public static final int SMFPTR_DIO_READ_CASH_REG = 0x1B;
    
    /** Read operation register **/
    public static final int SMFPTR_DIO_READ_OPER_REG = 0x1C;
 
    /* Execute command */
    public static final int SMFPTR_DIO_COMMAND_OBJECT = 0x1D;
   
    /* Save XML Z report */
    public static final int SMFPTR_DIO_XML_ZREPORT = 0x1E;
    
    /* Save CSV Z report */
    public static final int SMFPTR_DIO_CSV_ZREPORT = 0x1F;
    
    /* Write parameter */
    public static final int SMFPTR_DIO_WRITE_DEVICE_PARAMETER = 0x20;
    
    /* Read parameter */
    public static final int SMFPTR_DIO_READ_DEVICE_PARAMETER = 0x21;
    
    /////////////////////////////////////////////////////////////////////
    // Parameter constants for directIO commands:
    // FPTR_DIO_GET_DRIVER_PARAMETER,
    // FPTR_DIO_SET_DRIVER_PARAMETER
    /////////////////////////////////////////////////////////////////////
    
    /** Report device for printReport, printPeriodicTotalsReport **/
    public static final int SMFPTR_DIO_PARAM_REPORT_DEVICE = 0;
    
    /** Report type for printReport, printPeriodicTotalsReport **/
    public static final int SMFPTR_DIO_PARAM_REPORT_TYPE = 1;
    
    /** Number of header lines **/
    public static final int SMFPTR_DIO_PARAM_NUMHEADERLINES = 2;
    
    /** Number of trailer lines **/
    public static final int SMFPTR_DIO_PARAM_NUMTRAILERLINES = 3;
    
    /** Polling enabled **/
    public static final int SMFPTR_DIO_PARAM_POLL_ENABLED = 4;
    
    /////////////////////////////////////////////////////////////////////
    // TableMode
    public static final int SMFPTR_TABLE_MODE_AUTO      = 0;
    public static final int SMFPTR_TABLE_MODE_DISABLED  = 1;
    
    /////////////////////////////////////////////////////////////////////
    // CutMode
    public static final int SMFPTR_CUT_MODE_AUTO      = 0;
    public static final int SMFPTR_CUT_MODE_DISABLED  = 1;
}
