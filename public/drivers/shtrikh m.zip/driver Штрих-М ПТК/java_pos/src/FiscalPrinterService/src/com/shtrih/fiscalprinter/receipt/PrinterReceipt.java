/*
 * FiscalReceipt.java
 *
 * Created on April 3 2008, 20:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.receipt;

/**
 *
 * @author V.Kravtsov
 */
import org.apache.log4j.*;
import com.shtrih.util.*;
import com.shtrih.fiscalprinter.*;
import com.shtrih.fiscalprinter.command.*;

public class PrinterReceipt {

    private long total = 0;                     // receipt total
    private long lastItemSum = 0;               // last item amount
    private long[] paymentSum = new long[4];    // payment amounts
    private boolean cancelled = false;          // receipt is cancelled
    private final ReceiptItems items = new ReceiptItems();
    private static Logger logger = Logger.getLogger(PrinterReceipt.class);
    private ReceiptItem lastItem = null;

    /** Creates a new instance of FiscalReceipt */
    public PrinterReceipt() {
        reset();
    }

    public long[] getPaymentSums() {
        return paymentSum;
    }

    public void reset() 
    {
        logger.debug("reset");
        
        total = 0;
        lastItemSum = 0;
        paymentSum[0] = 0;
        paymentSum[1] = 0;
        paymentSum[2] = 0;
        paymentSum[3] = 0;
        cancelled = false;
        items.clear();
        lastItem = null;
    }

    public long getTotal() {
        logger.debug("getTotal: " + String.valueOf(total));
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void cancel() {
        cancelled = true;
    }

    public long getPaymentSum() {
        return paymentSum[0] + paymentSum[1] + paymentSum[2] + paymentSum[3];
    }

    public boolean isPayed() {
        return getPaymentSum() >= total;
    }

    public void printSale(long price, long quantity, int department,
            int vatInfo, String description) 
    {
        lastItemSum = PrinterAmount.getAmount(price, quantity);
        addtotal(lastItemSum);
        addReceiptItem(new SaleReceiptItem(price, quantity, department,
                vatInfo, 0, 0, 0, description));
    }

    public void addReceiptItem(ReceiptItem item){
        items.add(item);
        lastItem = item;
    }
        
    public void printSaleRefund(long price, long quantity, int department,
            int vatInfo, String description) {
        lastItemSum = PrinterAmount.getAmount(price, quantity);
        addtotal(lastItemSum);

        addReceiptItem(new RefundReceiptItem(price, quantity, department,
                vatInfo, 0, 0, 0, description));
    }

    public void printStorno(long price, int quantity, int department,
            int vatInfo, String description) {
        lastItemSum = PrinterAmount.getAmount(price, quantity);
        addtotal(-lastItemSum);

        addReceiptItem(new StornoItem(price, quantity, department,
                vatInfo, 0, 0, 0, description));
    }

    public long getItemPercentAdjustmentAmount(long amount) {
        return lastItemSum * amount / 10000;
    }

    public void addPayment(long payment, long payType) {
        logger.debug("addPayment("
                + String.valueOf(payment)
                + ", " + String.valueOf(payType) + ")");

        MethodParameter.checkRange(payType, 0, 3, "payType");
        paymentSum[(int) payType] += payment;
    }

    public void addtotal(long sum) {
        total += sum;
    }

    public void printDiscount(long amount, int tax1, int tax2, int tax3,
            int tax4, String text) {
        total -= amount;
        items.add(new DiscountItem(amount, tax1, tax2, tax3, tax4, text));
        if (lastItem != null){
            lastItem.addDiscount(amount);
        }
    }

    public void printCharge(long amount, int tax1, int tax2, int tax3,
            int tax4, String text) {
        total += amount;
        items.add(new ChargeItem(amount, tax1, tax2, tax3, tax4, text));
    }

    public ReceiptItems getItems() {
        return items;
    }

    public void print(SMFiscalPrinter printer)
            throws Exception {
        for (int i = 0; i < items.size(); i++) {
            ReceiptItem item = items.get(i);
            item.print(printer);
        }
    }
}