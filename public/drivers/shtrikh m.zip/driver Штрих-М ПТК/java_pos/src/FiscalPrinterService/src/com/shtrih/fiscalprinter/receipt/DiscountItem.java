/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shtrih.fiscalprinter.receipt;

import com.shtrih.fiscalprinter.*;

/**
 *
 * @author V.Kravtsov
 */
public class DiscountItem implements ReceiptItem {

    private long amount;
    private int tax1;
    private int tax2;
    private int tax3;
    private int tax4;
    private String text;

    public DiscountItem(
            long amount,
            int tax1,
            int tax2,
            int tax3,
            int tax4,
            String text) {
        this.amount = amount;
        this.tax1 = tax1;
        this.tax2 = tax2;
        this.tax3 = tax3;
        this.tax4 = tax4;
        this.text = text;
    }

    public long getAmount() {
        return amount;
    }

    public int getTax1() {
        return tax1;
    }

    public int getTax2() {
        return tax2;
    }

    public int getTax3() {
        return tax3;
    }

    public int getTax4() {
        return tax4;
    }

    public String getText() {
        return text;
    }

    public void print(SMFiscalPrinter printer)
            throws Exception {
        printer.printDiscount(amount, tax1, tax2, tax3, tax4, text);
    }
    
    public int getId(){
        return RECEIPT_ITEM_DISCOUNT;
    }
    
    public String getDescription(){
        return text;
    }
    
    public long getDiscount() {
        return 0;
    }
    
    public void addDiscount(long amount){
    }
}
