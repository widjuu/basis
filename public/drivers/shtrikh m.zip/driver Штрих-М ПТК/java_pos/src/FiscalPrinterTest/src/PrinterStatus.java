/*
 * PrinterStatus.java
 *
 * Created on 11 ������ 2009 �., 17:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author V.Kravtsov
 */
public class PrinterStatus {
    
    private final int mode;
    private final int flags;
    private final int subMode;
    private final int operator;
    
    /** Creates a new instance of PrinterStatus */
    public PrinterStatus(
        int mode,
        int subMode,
        int flags,
        int operator)
    {
        this.mode = mode;
        this.subMode = subMode;
        this.flags = flags;
        this.operator = operator;
    }
    
    public int getMode()
    {
        return mode;
    }
    
    public int getFlags()
    {
        return flags;
    }
        
    public int getSubMode()
    {
        return subMode;
    }
    
    public int getOperator()
    {
        return operator;
    }
    
    public PrinterFlags getPrinterFlags()
    {
        return new PrinterFlags(flags);
    }
    
    public PrinterMode getPrinterMode()
    {
        return new PrinterMode(mode);
    }
}
