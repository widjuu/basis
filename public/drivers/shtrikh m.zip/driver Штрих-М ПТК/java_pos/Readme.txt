Driver uses libraries:

   log4j-1.2.12.jar - log 
   comm.jar         - serial port API